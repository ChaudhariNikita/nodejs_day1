   use productdetails
   show dbs
   db  
   db.createCollection("products")
   show collections

   db.produts.insert([{"name":"shirt","price":400,"discount":10},{"name":"sweetshirt","price":450,"discount":9},{"name":"kurta","price":350,"discount":5}])